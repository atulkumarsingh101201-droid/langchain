# config.py
from datetime import datetime, timezone
from pymongo import MongoClient, AsyncMongoClient
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from azure.storage.blob.aio import BlobServiceClient
import os

from key_vault import get_secret

MONGO_URI = get_secret("mongoPersonConnectionString")
client = MongoClient(MONGO_URI)
aclient = AsyncMongoClient(MONGO_URI)

DB_NAME = "wingstop"
COLLECTION_NAME = "kb"
ATLAS_VECTOR_SEARCH_INDEX_NAME = "ws_index"


db = client[DB_NAME]
kb_collection = db[COLLECTION_NAME]

adb = aclient[DB_NAME]
akb_collection = adb[COLLECTION_NAME]

visualEnsembleCS = get_secret("connectionStringVisualEnsemble")
SUPPORTED_EXTENSIONS = {'.pdf', '.docx', '.xlsx', '.csv', '.txt', '.pptx'}
azure_container_name = "wingstop"
blob_service_client = BlobServiceClient.from_connection_string(visualEnsembleCS)
container_client_wingstop = blob_service_client.get_container_client(azure_container_name)

llm = AzureChatOpenAI(
    api_version="2024-10-21",
    azure_endpoint=get_secret("azureOpenAiEndpoint4o"),
    api_key=get_secret("azureOpenAiKey4o"),
    azure_deployment=get_secret("azureOpenAiModel4o"),
)


embeddings = AzureOpenAIEmbeddings(
    azure_deployment=get_secret("aoiEmbeddingSmallModel"),
    azure_endpoint=get_secret("aoiEmbeddingSmallEndpoint"),
    api_key=get_secret("aoiEmbeddingSmallKey"),
    model="text-embedding-3-small",
    disallowed_special=()
)

