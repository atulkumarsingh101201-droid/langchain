from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.core.exceptions import ResourceNotFoundError, ClientAuthenticationError
import os


# Initialize Key Vault client and credential
key_vault_name = "nextgensdlc"
key_vault_url = f"https://{key_vault_name}.vault.azure.net/"

# Create the credential and client instances
credential = DefaultAzureCredential()
client = SecretClient(vault_url=key_vault_url, credential=credential)

# Function to get secret value by name
def get_secret(key_name: str):
    try:
        retrieved_secret = client.get_secret(key_name)
        return retrieved_secret.value
    except ResourceNotFoundError:
        print(f"Error: The secret '{key_name}' was not found in Key Vault.")
        return None
    except ClientAuthenticationError:
        print("Error: Authentication to Azure Key Vault failed. Check your credentials.")
        return None
    except Exception as e:
        print(f"An unexpected error occurred while retrieving secret '{key_name}': {e}")
        return None