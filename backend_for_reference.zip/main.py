from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes.loaders_route import router as loaders_router
from routes.rag_route import router as rag_router

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Change this to specific domains in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(loaders_router)
app.include_router(rag_router)