from config import  embeddings, kb_collection, ATLAS_VECTOR_SEARCH_INDEX_NAME, visualEnsembleCS
from langchain_community.document_loaders import AzureBlobStorageFileLoader
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import MongoDBAtlasVectorSearch
from itertools import islice


def process_pdf(blob_data, email: str, namespace: str,
                chunk_size: int, chunk_overlap: int, split: bool):
    def batch_iterable(iterable, batch_size):
        """Yield successive batches from the iterable, including a final smaller batch if needed."""
        iterator = iter(iterable)
        for first in iterator:
            yield [first] + list(islice(iterator, batch_size - 1))

    try:
        if not blob_data:
            raise ValueError("No blob data provided for PDF processing")

        loader = PyPDFLoader(blob_data)
        pages = loader.load()

        if not pages:
            raise ValueError("No pages found in the PDF")

        # Add metadata
        for page in pages:
            page.metadata["email"] = email
            page.metadata["namespace"] = namespace

        docs = pages
        if split:
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=chunk_size, chunk_overlap=chunk_overlap
            )
            docs = text_splitter.split_documents(pages)

        if not docs:
            raise ValueError("No documents generated after splitting")

        batch_size = 15
        for batch in batch_iterable(docs, batch_size):
            MongoDBAtlasVectorSearch.from_documents(
                documents=batch,
                embedding=embeddings,
                collection=kb_collection,
                index_name=ATLAS_VECTOR_SEARCH_INDEX_NAME,
            )

        # logger.info("Vector uploaded in batches (PDF)")
        return {"status": "success", "message": "PDF uploaded in batches"}

    except (ValueError, IOError) as e:
        # logger.error(f"Validation/IO error while processing PDF: {e}")
        raise RuntimeError(f"Error processing PDF: {e}") from e
    except Exception as e:
        # logger.error("Unexpected error while processing PDF", exc_info=True)
        raise RuntimeError(f"Unexpected error while processing PDF: {str(e)}") from e


def process_common_files(container_name: str, blob_name: str, email: str, namespace: str,
                         chunk_size: int, chunk_overlap: int, split: bool):
    def batch_iterable(iterable, batch_size):
        """Yield successive batches from the iterable, including a final smaller batch if needed."""
        iterator = iter(iterable)
        for first in iterator:
            yield [first] + list(islice(iterator, batch_size - 1))

    try:
        if not blob_name:
            raise ValueError("Blob name must be provided")

        loader = AzureBlobStorageFileLoader(
            conn_str=visualEnsembleCS,
            container=container_name,
            blob_name=blob_name,
        )
        pages = loader.load()

        if not pages:
            raise ValueError(f"No pages found in blob: {blob_name}")

        # Add metadata
        for page in pages:
            page.metadata["email"] = email
            page.metadata["namespace"] = namespace

        docs = pages
        if split:
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=chunk_size, chunk_overlap=chunk_overlap
            )
            docs = text_splitter.split_documents(pages)

        if not docs:
            raise ValueError(f"No documents generated after splitting blob: {blob_name}")

        batch_size = 15
        for batch in batch_iterable(docs, batch_size):
            MongoDBAtlasVectorSearch.from_documents(
                documents=batch,
                embedding=embeddings,
                collection=kb_collection,
                index_name=ATLAS_VECTOR_SEARCH_INDEX_NAME,
            )

        # logger.info(f"Vector uploaded in batches for blob {blob_name}")
        return {"status": "success", "message": f"File {blob_name} uploaded in batches"}

    except (ValueError, IOError) as e:
        # logger.error(f"Validation/IO error while processing blob {blob_name}: {e}")
        raise RuntimeError(f"Error processing blob {blob_name}: {e}") from e
    except Exception as e:
        # logger.error(f"Unexpected error while processing blob {blob_name}", exc_info=True)
        raise RuntimeError(f"Unexpected error while processing blob {blob_name}: {str(e)}") from e