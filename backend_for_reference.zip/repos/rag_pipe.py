import os
from typing import List
from config import llm, embeddings, kb_collection, ATLAS_VECTOR_SEARCH_INDEX_NAME, aclient
from langchain_mongodb import MongoDBAtlasVectorSearch
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage
from langgraph.prebuilt import ToolNode, tools_condition
from langgraph.graph import MessagesState, StateGraph, END
from langchain_core.documents import Document
from langgraph.checkpoint.mongodb import AsyncMongoDBSaver
from IPython.display import Image


vector_store = MongoDBAtlasVectorSearch(
    embedding=embeddings,
    collection=kb_collection,
    index_name=ATLAS_VECTOR_SEARCH_INDEX_NAME,
    relevance_score_fn="cosine",
)

class State(MessagesState):
    context: List[Document]

@tool(response_format="content_and_artifact")
def retrieve(query: str):
    """Retrieve information related to a query. Alway query the ask."""
    retrieved_docs = vector_store.similarity_search(query, k=4)
    serialized = "\n\n".join(
        (f"Source: {doc.metadata}\nContent: {doc.page_content}")
        for doc in retrieved_docs
    )
    return serialized, retrieved_docs

graph_builder = StateGraph(MessagesState)
c_graph_builder = StateGraph(MessagesState)


# Step 1: Generate an AIMessage that may include a tool-call to be sent.
def query_or_respond(state: MessagesState):
    """Generate tool call for retrieval or respond."""
    llm_with_tools = llm.bind_tools([retrieve])
    system_message_content = (
        "You are an ai assistant for Wingstop Organization and your work is question-answering tasks. "
        "Your name is 'Saucey'. "
        "Use the provided tool for retrieval from knowledge base."
        "Don't answer out of the knowledge base and if you don't know simply say that provided documents don't have the info."
        "You must use the retrieve tool whever user queries. You should never answer from general knowledge that isn't grounded in search results"
        "\n\n")
    conversation_messages = [
        message
        for message in state["messages"]
        if message.type in ("human", "system")
        or (message.type == "ai" and not message.tool_calls)
    ]
    prompt = [SystemMessage(system_message_content)] + conversation_messages
    response = llm_with_tools.invoke(prompt)
    # MessagesState appends messages to state instead of overwriting
    return {"messages": [response]}


#################  For Customer  ##########
# def customer_query_or_respond(state: MessagesState):
#     """Generate tool call for retrieval or respond."""
#     llm_with_tools = llm.bind_tools([retrieve])
#     system_message_content = (
#         "You are an ai assistant for Wingstop Organization and your work is question-answering tasks. "
#         "Your name is 'Saucey' and you are facing it's customer's queries so answer like you are front for organization."
#         "Use the provided tool for retrieval from knowledge base."
#         "Don't answer out of the knowledge base and if you don't know simply say that provided documents don't have the info."
#         "You must use the retrieve tool whenever user queries. You should never answer from general knowledge that isn't grounded in search results"
#         "\n\n")
#     conversation_messages = [
#         message
#         for message in state["messages"]
#         if message.type in ("human", "system")
#         or (message.type == "ai" and not message.tool_calls)
#     ]
#     prompt = [SystemMessage(system_message_content)] + conversation_messages
#     response = llm_with_tools.invoke(prompt)
#     # MessagesState appends messages to state instead of overwriting
#     return {"messages": [response]}

#######################################################

# Step 2: Execute the retrieval.
tools = ToolNode([retrieve])


# Step 3: Generate a response using the retrieved content.
def generate(state: MessagesState):
    """Generate answer."""
    # Get generated ToolMessages
    recent_tool_messages = []
    for message in reversed(state["messages"]):
        if message.type == "tool":
            recent_tool_messages.append(message)
        else:
            break
    tool_messages = recent_tool_messages[::-1]

    # Format into prompt
    docs_content = "\n\n".join(doc.content for doc in tool_messages)
    system_message_content = (
        "You are an ai assistant for Wingstop and your work is question-answering tasks. "
        "Your name is 'Saucey' and you are facing the internal employee's queries"
        "Use the following pieces of retrieved context to answer "
        "the question. If you don't know the answer, say that you "
        "don't know. Use three sentences maximum and keep the "
        "answer concise and explain those where needed."
        "\n\n"
        f"{docs_content}"
    )
    conversation_messages = [
        message
        for message in state["messages"]
        if message.type in ("human", "system")
        or (message.type == "ai" and not message.tool_calls)
    ]
    prompt = [SystemMessage(system_message_content)] + conversation_messages

    # Run
    response = llm.invoke(prompt)
    context = []
    for tool_message in tool_messages:
        context.extend(tool_message.artifact)
    return {"messages": [response], "context": context}

####################### For Customer ###############################
# def c_generate(state: MessagesState):
#     """Generate answer."""
#     # Get generated ToolMessages
#     recent_tool_messages = []
#     for message in reversed(state["messages"]):
#         if message.type == "tool":
#             recent_tool_messages.append(message)
#         else:
#             break
#     tool_messages = recent_tool_messages[::-1]

#     # Format into prompt
#     docs_content = "\n\n".join(doc.content for doc in tool_messages)
#     system_message_content = (
#         "You are an ai assistant for Wingstop Organization and your work is question-answering tasks. "
#         "you are primarily facing the cutomer's queries."
#         "You need to answer in generic mode don't go in technical as the context may be technical and for employees."
#         "Remember you need to answer that to customers not employees so adjust the tone."
#         "\n\n"
#         f"{docs_content}"
#     )
#     conversation_messages = [
#         message
#         for message in state["messages"]
#         if message.type in ("human", "system")
#         or (message.type == "ai" and not message.tool_calls)
#     ]
#     prompt = [SystemMessage(system_message_content)] + conversation_messages

#     # Run
#     response = llm.invoke(prompt)
#     context = []
#     for tool_message in tool_messages:
#         context.extend(tool_message.artifact)
#     return {"messages": [response], "context": context}

###################################################################

graph_builder.add_node(query_or_respond)
graph_builder.add_node(tools)
graph_builder.add_node(generate)

graph_builder.set_entry_point("query_or_respond")
graph_builder.add_conditional_edges(
    "query_or_respond",
    tools_condition,
    {END: END, "tools": "tools"},
)
graph_builder.add_edge("tools", "generate")
graph_builder.add_edge("generate", END)

async_memory = AsyncMongoDBSaver(
    client= aclient,
    db_name= "wingstop"
)
async_graph = graph_builder.compile(checkpointer=async_memory)

################################# For Customer #########################
# c_graph_builder.add_node(customer_query_or_respond)
# c_graph_builder.add_node(tools)
# c_graph_builder.add_node(c_generate)

# c_graph_builder.set_entry_point("customer_query_or_respond")
# c_graph_builder.add_conditional_edges(
#     "customer_query_or_respond",
#     tools_condition,
#     {END: END, "tools": "tools"},
# )
# c_graph_builder.add_edge("tools", "c_generate")
# c_graph_builder.add_edge("c_generate", END)

# async_memory = AsyncMongoDBSaver(
#     client= aclient,
#     db_name= "wingstop"
# )
# c_async_graph = c_graph_builder.compile(checkpointer=async_memory)

# #######################################################################

try:
    img = Image(async_graph.get_graph().draw_mermaid_png())
    img_data = img.data

    # Get the directory of the current script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    file_name = "graph1.png"
    file_path = os.path.join(script_dir, file_name)

    # Save the image data to a file
    with open(file_path, "wb") as f:
        f.write(img_data)

    print(f"Image saved to {file_path}")

except Exception as e:
    print(f"An error occurred: {e}")




# try:
#     img = Image(c_async_graph.get_graph().draw_mermaid_png())
#     img_data = img.data

#     # Get the directory of the current script
#     script_dir = os.path.dirname(os.path.abspath(__file__))
#     file_name = "customer.png"
#     file_path = os.path.join(script_dir, file_name)

#     # Save the image data to a file
#     with open(file_path, "wb") as f:
#         f.write(img_data)

#     print(f"Image saved to {file_path}")

# except Exception as e:
#     print(f"An error occurred: {e}")