import io
import os
from typing import List
from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from config import SUPPORTED_EXTENSIONS, container_client_wingstop, azure_container_name
from repos.loaders import process_common_files, process_pdf

router = APIRouter(prefix="/loaders", tags=["Document Loaders"])


async def delete_all_blobs():
    async for blob in container_client_wingstop.list_blobs():
        await container_client_wingstop.delete_blob(blob.name)

@router.post("/load-documents-from-common-files")
async def upload_files_SDLC(
    email: str = Form(...),
    namespace: str = Form(...),
    split: bool = Form(...),
    chunk_size: int = Form(...),
    chunk_overlap: int = Form(...),
    files: List[UploadFile] = File(...)
):
    """
    Upload multiple documents and process them.
    Metadata comes from form fields, files are uploaded separately.
    """
    uploaded_urls = []

    # Validate
    if not files:
        raise HTTPException(status_code=400, detail="No files uploaded")

    for file in files:
        # process each file like before
        ext = os.path.splitext(file.filename)[1].lower()
        if ext not in SUPPORTED_EXTENSIONS:
            raise HTTPException(status_code=400, detail=f"Unsupported document format: {ext}")

        file_content = await file.read()
        blob_client = container_client_wingstop.get_blob_client(file.filename)

        with io.BytesIO(file_content) as stream:
            await blob_client.upload_blob(stream, overwrite=True)

        # Pass metadata to repo functions
        if ext == ".pdf":
            process_pdf(
                blob_client.url,
                email=email,
                namespace=namespace,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                split=split,
            )
        else:
            process_common_files(
                azure_container_name,
                file.filename,
                email=email,
                namespace=namespace,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                split=split,
            )

        uploaded_urls.append(file.filename)

    return {"status": "success", "uploaded": uploaded_urls}