from uuid import uuid4
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from repos.rag_pipe import async_graph

router = APIRouter(prefix="/ai", tags =["GraphAI Routes"])

class QuestionRequest(BaseModel):
    question: str
    thread_id: str
    user_email: str

def doc_to_dict(doc):
    return {
        "id": getattr(doc, "id", None),
        "metadata": getattr(doc, "metadata", {}),
        "page_content": getattr(doc, "page_content", ""),
        "type": getattr(doc, "type", "Document")
    }

@router.post("/async-agent")
async def process_question(request: QuestionRequest):
    # if request.user_email:
    #     user = await AuthRepo.get_user_by_email(email=request.user_email)
    #     if not user:
    #         raise HTTPException(status_code=404, detail="User not found")

    question = request.question
    thread_id = request.thread_id
    email = request.user_email

    config = {
        "configurable": {
            "thread_id": thread_id,
            "user_email": email,
        }
    }

    try:
        response_events = []

        async for event in async_graph.astream(
            {"messages": [("user", question)]}, config, stream_mode="values"
        ):
            response_events.append(event)

        if response_events:
            last_event = response_events[-1]

            # Safely extract message from last event
            if "messages" in last_event:
                messages = last_event["messages"]
                if messages:
                    last_message = messages[-1]
                    return {"content": last_message.content}
                else:
                    raise HTTPException(status_code=404, detail="No messages in last event")
            else:
                raise HTTPException(status_code=404, detail="No 'messages' key in last event")

        else:
            raise HTTPException(status_code=404, detail="No events received")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))




@router.post("/process_question")
async def process_question(request: QuestionRequest):
    # if (request.user_email):
    #     user = await AuthRepo.get_user_by_email(email=request.user_email)
    #     if not user:
    #         raise HTTPException(status_code=404, detail="User not found")
    #     # question = request.question + "Current(mine) UserEmail:" + user["email"]
    
    question = request.question
    
    try:
        thread_id = request.thread_id 
        email = request.user_email
        config = {
            "configurable": {
                # Checkpoints are accessed by thread_id
                "thread_id": thread_id,
                "user_email": email,
            }
        }
        events = async_graph.astream(
            {"messages": ("user", question)}, config, stream_mode="values"
        )
        response_events = []
        async for event in events:
            print(event)
            response_events.append(event)
        return response_events
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# @router.post("/chat")
# async def test_stream_question(request: QuestionRequest):
#     try:
#         config = {
#             "configurable": {
#                 "thread_id": request.thread_id,
#                 "user_email": request.user_email,
#             }
#         }

#         chunks = []
#         message_chunks = []
#         ai_stream_id = str(uuid4())

#         # ---- Notify frontend: AI stream start ----
#         await send_to_frontend(
#             user_email=request.user_email,
#             msg_type="call_frontend",
#             target_component="home",
#             target_function="receive_chunks",
#             payload={"event": "start", "type": "ai", "stream_id": ai_stream_id},
#             splitmode=False
#         )

#         # ---- Stream messages from graph ----
#         async for message_chunk, metadata in async_graph.astream(
#             {"messages": ("user", request.question)}, config, stream_mode="messages"
#         ):
#             message_chunks.append(message_chunk)

#             kind = "tool" if getattr(message_chunk, "type", "") == "tool" else "ai"

#             # --- AI Message Chunks ---
#             if kind == "ai":
#                 if message_chunk.content or message_chunk.tool_calls or message_chunk.invalid_tool_calls:
#                     chunks.append(message_chunk.content)
#                     await send_to_frontend(
#                         user_email=request.user_email,
#                         msg_type="call_frontend",
#                         target_component="home",
#                         target_function="receive_chunks",
#                         payload={
#                             "event": "chunk",
#                             "type": "ai",
#                             "stream_id": ai_stream_id,
#                             "chunk": message_chunk.content or "",
#                             # include tool call info if present
#                             "tool_calls": message_chunk.tool_calls,
#                             "invalid_tool_calls": message_chunk.invalid_tool_calls
#                         }
#                     )

#             # --- Tool Messages ---
#             else:  
#                 tool_artifacts = [doc_to_dict(d) for d in getattr(message_chunk, "artifact", [])]
#                 await send_to_frontend(
#                     user_email=request.user_email,
#                     msg_type="call_frontend",
#                     target_component="home",
#                     target_function="receive_chunks",
#                     payload={
#                         "event": "tool",
#                         "type": "tool",
#                         "stream_id": ai_stream_id,   # link tool to AI stream
#                         "tool_name": getattr(message_chunk, "name", None),
#                         "content": message_chunk.content,
#                         "artifact": tool_artifacts,
#                         "status": "success"
#                     }
#                 )

#         # ---- Notify frontend: AI stream end ----
#         await send_to_frontend(
#             user_email=request.user_email,
#             msg_type="call_frontend",
#             target_component="home",
#             target_function="receive_chunks",
#             payload={"event": "end", "type": "ai", "stream_id": ai_stream_id}
#         )

#         # ---- Return aggregated response ----
#         return {
#             "type": "done",
#             "chunks": chunks,
#             "message_chunks": message_chunks,
#             "full_response": "".join(chunks),
#         }

#     except Exception as e:
#         return {"error": str(e)}
    



    ###########################################

